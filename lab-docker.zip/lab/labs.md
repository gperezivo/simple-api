# Laboratorios Docker

## Argumentos de compilación

Basandonos en el Dockerfile de la ruta `lab/web/Dockerfile` tenemos que:
- Añadir un argumento de compilación para definir cual de las imagenes se definirá como `main.png`
- Usando el argumento, copiar la imagen principal a la ruta `/usr/local/apache2/htdocs/main.png`

### Archivo original Dockerfile


```Dockerfile
FROM httpd:2.4

COPY ./content/ /usr/local/apache2/htdocs/
```

El contendor arrancará un servidor web que cargará el siguiente HTML
```html
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lab</title>
   </head>
   <body>
       <img src="main.png" alt="main" width="100%" height="100%">
       
   </body>
</html>
```

## Variables de entorno

Utilizando el dockerfile que tenemos en la ruta `lab/api/Dockerfile` tenemos que:

- Crear una nueva variable de entorno llamada `MyVar2`
- Compilar la nueva imagen llamandola `lab-api`
- Ejecutar el contenedor `lab-api` pasandole la variable de entorno `MyVar2` y verificar que se muestre el valor de la variable al acceder por navegador

> Notas:
> 
> - El contenedor simple-api escucha el puerto 80 y espera una petición GET 
> - Al ejecutar el contenedor tenemos que establecer un puerto local


```Dockerfile
FROM gperezivo/simple-api
```